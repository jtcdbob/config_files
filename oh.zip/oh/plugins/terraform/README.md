## atom

Plugin for Terraform, a tool from Hashicorp for managing infrastructure safely and efficiently.

### Requirements

 * [Terraform](https://terraform.io/)

### Usage

 * Type `terraform` into your prompt and hit `TAB` to see available completion options
